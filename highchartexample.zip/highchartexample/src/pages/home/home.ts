import { Component,OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';
import  * as Highcharts from 'highcharts';
import * as borderRadius from 'highcharts-border-radius'


'use strict';
borderRadius(Highcharts);
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage implements OnInit {

  constructor(public navCtrl: NavController) {

  }
  ngOnInit(){
   
  }

  chart:any;
create(){
   

let chartItems=[
    {
        type: 'column',
        name:'Bud',
        data: [38,38,40,39,39,39],
        color:'#05B0D0', 
        borderRadiusTopLeft: 7,
        borderRadiusTopRight: 7,
        
   }, 
   {
        type: 'column',
        name:'Act',
        data: [35,40,33,42,42,42],
        color:'#D7D7D7',
        borderRadiusTopLeft: 7,
        borderRadiusTopRight: 7,
        
    },
    {
    
        type: 'spline',
        name: 'Cumulative Actual',
        data: [0,58,90,114,125,135],
        color:"#11A5F3",
        marker: {
            lineWidth: 2,
            lineColor: null,
            fillColor: 'orange',
            symbol: 'circle'
        }
    },
    {
        type: 'spline',
        name: 'Cumulative Actual',
        data: [0,62, 95, 122, 138, 150],
        color:"#CBCBCB",
        marker: {
            lineWidth: 2,
            lineColor: null,
            fillColor: 'white',
             symbol: 'circle'
        }
    }]

 this.chart=Highcharts.chart('container', {
     title: {
         text: 'QPM Chart Demo'
     },
     xAxis: {
         categories: ['May', 'June', 'July', 'Aug', 'Sep','oct'],
          crosshair: true
     }, 
     
     yAxis: {
        lineWidth: 1,
    },
    
    credits: {
        enabled: false
     },

    legend: {
        enabled: false
    },

    tooltip:{
        borderRadius: 10,
        borderWidth: 0,
        padding:4,
        useHTML:true,
       
        formatter: function () {
            
       let   index=this.point.series.points.indexOf(this.point)
            if(this.series && this.series.type=="column"){

                let points=chartItems. filter(function(item){
                    return item.type=="column";
                });

                return points.reduce(function (s, item) {   

                    if(s)
                        s=  s+'</span><hr>'
                    let color=item.color||"#05B0D0"

                        return   s  + item.name +'<span style="color:'+color+';">&nbsp;&nbsp;&nbsp; ' +
                                item.data[index] +'&nbsp;&nbsp;&nbsp';
                        

                }, "");
        }else{
            let split=this.series.name.split(" ");
            return      split[0]+'<br/>&nbsp;&nbsp;&nbsp'+split[1] + '</br><span style="color:'+this.color+';">&nbsp;&nbsp;&nbsp; ' +
            this.y +'</span>';
        }
                   
        },
      shared:false
    }  
     
 });
chartItems.forEach(item => {
    this.chart.addSeries(item)
   
});
}
}